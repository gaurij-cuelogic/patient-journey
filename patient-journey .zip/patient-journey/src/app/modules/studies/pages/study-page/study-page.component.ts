import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-study-page',
  templateUrl: './study-page.component.html',
  styleUrls: ['./study-page.component.sass']
})
export class StudyPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
