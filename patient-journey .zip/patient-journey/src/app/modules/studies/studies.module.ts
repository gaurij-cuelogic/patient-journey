import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudyPageComponent } from './pages/study-page/study-page.component';



@NgModule({
  declarations: [StudyPageComponent],
  imports: [
    CommonModule
  ],
  exports: [StudyPageComponent]
})
export class StudiesModule { }
