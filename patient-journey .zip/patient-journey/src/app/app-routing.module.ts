import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudyPageComponent } from './modules/studies/pages/study-page/study-page.component';


const routes: Routes = [
  { path: '', component: StudyPageComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
